# Nash-GNN
Nash-GNN - for reviewing
